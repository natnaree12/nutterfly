<br>
<br>
<center><a class='btn btn-info' href='#' role='button'>เพิ่มออเดอร์</a></center>
<br>
<center><nav aria-label="...">
  <ul class="pager">
  	<li><a href="<?php echo base_url('/index.php/material'); ?>">ทั้งหมด</a></li>
    <li><a href="<?php echo base_url('/index.php/material/view_raw_material'); ?>">กำลังทำ</a></li>
    <li><a href="<?php echo base_url('/index.php/material/view_package'); ?>">ทำเสร็จแล้ว</a></li>
  </ul>
</nav></center>