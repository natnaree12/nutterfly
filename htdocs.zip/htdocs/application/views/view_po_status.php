<center><nav aria-label="...">
  <ul class="pager">
  	<li><a href="<?php echo base_url('/index.php/purchase'); ?>">ดูใบสั่งซื้อทั้งหมด</a></li>
  </ul>
</nav></center>