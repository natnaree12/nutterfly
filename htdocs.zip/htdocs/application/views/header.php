<html>
        <head>
                <title>CodeIgniter Tutorial</title>
                <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
        </head>
        <body style="margin-left: 12px">
	  <div class="row">
	    <nav class="navbar navbar-default">
	  		<div class="container-fluid">
	    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>
			      <a class="navbar-brand" href="#">Little Bear Bread</a>
			    </div>
			</div><!-- /.container-fluid -->
		</nav>
	</div>
	<div class="row">
		<div class="col-md-6">
			<ul class="nav nav-tabs">
			  <li role="presentation"><a href="<?php echo base_url('/index.php/test'); ?>">หน้าหลัก</a></li>
			  <li role="presentation"><a href="<?php echo base_url('/index.php/test'); ?>">รายการ</a></li>
			  <li role="presentation"><a href="<?php echo base_url('/index.php/material'); ?>">วัตถุดิบ</a></li>
			</ul>
		</div>
	</div>